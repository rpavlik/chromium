#include "seethroughspu.h"
#include "cr_glwrapper.h"
#include "cr_error.h"

void SEETHROUGHSPU_APIENTRY seethroughMaterialfv( GLenum face, GLenum mode, const GLfloat *param )
{
	GLfloat local_param[4];
	if (mode == GL_SHININESS)
	{
		// nothing to do
		seethrough_spu.super.Materialfv( face, mode, param );
	}
	else
	{
		local_param[0] = param[0];
		local_param[1] = param[1];
		local_param[2] = param[2];
		local_param[3] = seethrough_spu.opacityf;
		seethrough_spu.super.Materialfv( face, mode, local_param );
	}
}

void SEETHROUGHSPU_APIENTRY seethroughMaterialiv( GLenum face, GLenum mode, const GLint *param )
{
	GLint local_param[4];
	if (mode == GL_SHININESS)
	{
		seethrough_spu.super.Materialiv( face, mode, param );
	}
	else
	{
		local_param[0] = param[0];
		local_param[1] = param[1];
		local_param[2] = param[2];
		local_param[3] = seethrough_spu.opacityi;
		seethrough_spu.super.Materialiv( face, mode, local_param );
	}
}

void SEETHROUGHSPU_APIENTRY seethroughDisable( GLenum cap )
{
	if (cap == GL_BLEND)
	{
		crWarning( "SeeThroughSPU: Ignoring disable of blending!" );
		seethrough_spu.super.BlendFunc( seethrough_spu.sfactor, seethrough_spu.dfactor );
	}
	else
	{
		seethrough_spu.super.Disable( cap );
	}
}

void SEETHROUGHSPU_APIENTRY seethroughEnable( GLenum cap )
{
	if (cap == GL_DEPTH_TEST)
	{
		crWarning( "SeeThroughSPU: Ignoring enable of depth!" );
	}
	else if (cap == GL_CULL_FACE)
	{
		crWarning( "SeeThroughSPU: Ignoring enable of face culling!" );
	}
	else
	{
		seethrough_spu.super.Enable( cap );
	}
}
