#include "cr_spu.h"
#include "seethroughspu.h"
#include <stdio.h>

extern SPUNamedFunctionTable seethrough_table[];

SPUFunctions the_functions = {
	NULL, // CHILD COPY
	NULL, // DATA
	seethrough_table // THE ACTUAL FUNCTIONS
};

SPUFunctions *SPUInit( int id, SPU *child, SPU *super,
		unsigned int context_id,
		unsigned int num_contexts )
{

	(void) super;
	(void) context_id;
	(void) num_contexts;

	seethrough_spu.id = id;
	seethrough_spu.has_child = 0;
	if (child)
	{
		crSPUCopyDispatchTable( &(seethrough_spu.child), &(child->dispatch_table) );
		seethrough_spu.has_child = 1;
	}
	crSPUCopyDispatchTable( &(seethrough_spu.super), &(super->dispatch_table) );
	seethroughspuGatherConfiguration();

	seethroughspuBuildFunctionTable();

	seethrough_spu.super.Enable( GL_BLEND );
	seethrough_spu.super.Disable( GL_CULL_FACE );
	seethrough_spu.super.BlendFunc( seethrough_spu.sfactor, seethrough_spu.dfactor );

	crStateInit();
	seethrough_spu.ctx = crStateCreateContext();
	crStateMakeCurrent( seethrough_spu.ctx );

	return &the_functions;
}

void SPUSelfDispatch(SPUDispatchTable *parent)
{
	(void)parent;
}

int SPUCleanup(void)
{
	return 1;
}

int SPULoad( char **name, char **super, SPUInitFuncPtr *init,
	SPUSelfDispatchFuncPtr *self, SPUCleanupFuncPtr *cleanup )
{
	*name = "seethrough";
	*super = "passthroughspu";
	*init = SPUInit;
	*self = SPUSelfDispatch;
	*cleanup = SPUCleanup;
	
	return 1;
}
