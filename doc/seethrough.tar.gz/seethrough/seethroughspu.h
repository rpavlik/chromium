#ifndef SEETHROUGH_SPU_H
#define SEETHROUGH_SPU_H

#ifdef WINDOWS
#define SEETHROUGHSPU_APIENTRY __stdcall
#else
#define SEETHROUGHSPU_APIENTRY
#endif

#include "cr_spu.h"
#include "cr_glwrapper.h"
#include "cr_glstate.h"

void seethroughspuGatherConfiguration( void );

typedef struct {
	int id;
	int has_child;
	SPUDispatchTable child, super;
	GLbyte   opacityb;
	GLdouble opacityd;
	GLfloat  opacityf;
	GLint    opacityi;
	GLshort  opacitys;
	GLubyte  opacityub;
	GLuint   opacityui;
	GLushort opacityus;

	GLenum sfactor, dfactor;

	CRContext *ctx;
} SeethroughSPU;

extern SeethroughSPU seethrough_spu;

void seethroughspuBuildFunctionTable( void );

#endif /* SEETHROUGH_SPU_H */
