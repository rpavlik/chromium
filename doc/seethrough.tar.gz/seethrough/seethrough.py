import sys,os;
import cPickle;
import string;
import re;

sys.path.append( "../../opengl_stub" )
parsed_file = open( "../../glapi_parser/gl_header.parsed", "rb" )
gl_mapping = cPickle.load( parsed_file )

import stub_common;

print """
#include <stdio.h>
#include "cr_spu.h"
#include "cr_string.h"
#include "cr_glwrapper.h"
#include "seethroughspu.h"

SeethroughSPU seethrough_spu;
"""

for type in ['b', 'd', 'f', 'i', 's', 'ub', 'ui', 'us']:
	for components in [3, 4]:
		func_name = 'Color%d%s' % (components, type)
		(return_type, arg_names, arg_types) = gl_mapping[func_name]
		print 'void SEETHROUGHSPU_APIENTRY seethrough%s%s' % (func_name, stub_common.ArgumentString( arg_names, arg_types ) )
		print '{'
		if components == 3:
			arg_names.append( 'seethrough_spu.opacity%s' % type )
		else:
			print '\t(void) %s;' % arg_names[3]
			arg_names[3] = 'seethrough_spu.opacity%s' % type

		new_func_name = 'Color4%s' % type
		print '\tseethrough_spu.super.%s%s;' % (new_func_name, stub_common.CallString( arg_names ) )
		print '}'
		print ''

		func_name = 'Color%d%sv' % (components, type)
		(return_type, arg_names, arg_types) = gl_mapping[func_name]
		print 'void SEETHROUGHSPU_APIENTRY seethrough%s%s' % (func_name, stub_common.ArgumentString( arg_names, arg_types ) )
		print '{'
		new_func_name = 'Color4%s' % type
		new_names = [ 'v[0]', 'v[1]', 'v[2]', 'seethrough_spu.opacity%s' % type ]
		print '\tseethrough_spu.super.%s%s;' % (new_func_name, stub_common.CallString( new_names ) )
		print '}'
		print ''

for func_name in stub_common.AllSpecials( "seethrough_state" ):
		(return_type, arg_names, arg_types) = gl_mapping[func_name]
		print 'void SEETHROUGHSPU_APIENTRY seethrough%s%s' % (func_name, stub_common.ArgumentString( arg_names, arg_types ) )
		print '{'
		print '\tcrState%s%s;' % (func_name, stub_common.CallString( arg_names ) )
		print '\tseethrough_spu.super.%s%s;' % (func_name, stub_common.CallString( arg_names ) )
		print '}'
 
for func_name in stub_common.AllSpecials( "seethrough" ):
        if not func_name.startswith( "Color" ):
                (return_type, arg_names, arg_types) = gl_mapping[func_name]
                print 'extern void SEETHROUGHSPU_APIENTRY seethrough%s%s;' % (func_name, stub_common.ArgumentString( arg_names, arg_types ) )

print 'SPUNamedFunctionTable seethrough_table[%d];' % ( len(stub_common.AllSpecials( "seethrough_state" )) + len(stub_common.AllSpecials( "seethrough" )) + 1 )

print """
static void __fillin( int offset, char *name, SPUGenericFunction func )
{
        seethrough_table[offset].name = crStrdup( name );
        seethrough_table[offset].fn = func;
}""" 

print 'void seethroughspuBuildFunctionTable( void )'
print '{'
offset = 0
for func_name in stub_common.AllSpecials( "seethrough" ):
        print '\t__fillin( %d, "%s", (SPUGenericFunction) seethrough%s );' % (offset, func_name, func_name )
        offset += 1
for func_name in stub_common.AllSpecials( "seethrough_state" ):
        print '\t__fillin( %d, "%s", (SPUGenericFunction) seethrough%s );' % (offset, func_name, func_name )
        offset += 1
print '\t__fillin( %d, NULL, (SPUGenericFunction) NULL );' % offset
print '}'
