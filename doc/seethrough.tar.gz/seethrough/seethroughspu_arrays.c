#include "seethroughspu.h"
#include "cr_glwrapper.h"
#include "cr_glstate.h"
#include "cr_error.h"

extern void SEETHROUGHSPU_APIENTRY seethroughColor3bv(GLbyte *p);
extern void SEETHROUGHSPU_APIENTRY seethroughColor4bv(GLbyte *p);
extern void SEETHROUGHSPU_APIENTRY seethroughColor3ubv(GLubyte *p);
extern void SEETHROUGHSPU_APIENTRY seethroughColor4ubv(GLubyte *p);
extern void SEETHROUGHSPU_APIENTRY seethroughColor3sv(GLshort *p);
extern void SEETHROUGHSPU_APIENTRY seethroughColor4sv(GLshort *p);
extern void SEETHROUGHSPU_APIENTRY seethroughColor3usv(GLushort *p);
extern void SEETHROUGHSPU_APIENTRY seethroughColor4usv(GLushort *p);
extern void SEETHROUGHSPU_APIENTRY seethroughColor3iv(GLint *p);
extern void SEETHROUGHSPU_APIENTRY seethroughColor4iv(GLint *p);
extern void SEETHROUGHSPU_APIENTRY seethroughColor3uiv(GLuint *p);
extern void SEETHROUGHSPU_APIENTRY seethroughColor4uiv(GLuint *p);
extern void SEETHROUGHSPU_APIENTRY seethroughColor3fv(GLfloat *p);
extern void SEETHROUGHSPU_APIENTRY seethroughColor4fv(GLfloat *p);
extern void SEETHROUGHSPU_APIENTRY seethroughColor3dv(GLdouble *p);
extern void SEETHROUGHSPU_APIENTRY seethroughColor4dv(GLdouble *p);

void SEETHROUGHSPU_APIENTRY seethroughArrayElement (GLint index) 
{
	CRClientState *c = &(seethrough_spu.ctx->client);
	unsigned char *p;

	if (index < 0)
	{
		crError( "seethroughArrayElement called with a negative index: %d", index );
	}

	if (c->e.enabled) 
	{
		seethrough_spu.super.EdgeFlagv(c->e.p + index*c->e.stride);
	}
	if (c->t[c->curClientTextureUnit].enabled) 
	{
		p = c->t[c->curClientTextureUnit].p + index*c->t[c->curClientTextureUnit].stride;
		switch (c->t[c->curClientTextureUnit].type) 
		{
			case GL_SHORT:
				switch (c->t[c->curClientTextureUnit].size) 
				{
					case 1: seethrough_spu.super.TexCoord1sv((GLshort *)p); break;
					case 2: seethrough_spu.super.TexCoord2sv((GLshort *)p); break;
					case 3: seethrough_spu.super.TexCoord3sv((GLshort *)p); break;
					case 4: seethrough_spu.super.TexCoord4sv((GLshort *)p); break;
				}
				break;
			case GL_INT:
				switch (c->t[c->curClientTextureUnit].size) 
				{
					case 1: seethrough_spu.super.TexCoord1iv((GLint *)p); break;
					case 2: seethrough_spu.super.TexCoord2iv((GLint *)p); break;
					case 3: seethrough_spu.super.TexCoord3iv((GLint *)p); break;
					case 4: seethrough_spu.super.TexCoord4iv((GLint *)p); break;
				}
				break;
			case GL_FLOAT:
				switch (c->t[c->curClientTextureUnit].size) 
				{
					case 1: seethrough_spu.super.TexCoord1fv((GLfloat *)p); break;
					case 2: seethrough_spu.super.TexCoord2fv((GLfloat *)p); break;
					case 3: seethrough_spu.super.TexCoord3fv((GLfloat *)p); break;
					case 4: seethrough_spu.super.TexCoord4fv((GLfloat *)p); break;
				}
				break;
			case GL_DOUBLE:
				switch (c->t[c->curClientTextureUnit].size) 
				{
					case 1: seethrough_spu.super.TexCoord1dv((GLdouble *)p); break;
					case 2: seethrough_spu.super.TexCoord2dv((GLdouble *)p); break;
					case 3: seethrough_spu.super.TexCoord3dv((GLdouble *)p); break;
					case 4: seethrough_spu.super.TexCoord4dv((GLdouble *)p); break;
				}
				break;
		}
	}
	if (c->i.enabled) 
	{
		p = c->i.p + index*c->i.stride;
		switch (c->i.type) 
		{
			case GL_SHORT: seethrough_spu.super.Indexsv((GLshort *)p); break;
			case GL_INT: seethrough_spu.super.Indexiv((GLint *)p); break;
			case GL_FLOAT: seethrough_spu.super.Indexfv((GLfloat *)p); break;
			case GL_DOUBLE: seethrough_spu.super.Indexdv((GLdouble *)p); break;
		}
	}
	if (c->c.enabled) 
	{
		p = c->c.p + index*c->c.stride;
		switch (c->c.type) 
		{
			case GL_BYTE:
				switch (c->c.size) 
				{
					case 3: seethroughColor3bv((GLbyte *)p); break;
					case 4: seethroughColor4bv((GLbyte *)p); break;
				}
				break;
			case GL_UNSIGNED_BYTE:
				switch (c->c.size) 
				{
					case 3: seethroughColor3ubv((GLubyte *)p); break;
					case 4: seethroughColor4ubv((GLubyte *)p); break;
				}
				break;
			case GL_SHORT:
				switch (c->c.size) 
				{
					case 3: seethroughColor3sv((GLshort *)p); break;
					case 4: seethroughColor4sv((GLshort *)p); break;
				}
				break;
			case GL_UNSIGNED_SHORT:
				switch (c->c.size) 
				{
					case 3: seethroughColor3usv((GLushort *)p); break;
					case 4: seethroughColor4usv((GLushort *)p); break;
				}
				break;
			case GL_INT:
				switch (c->c.size) 
				{
					case 3: seethroughColor3iv((GLint *)p); break;
					case 4: seethroughColor4iv((GLint *)p); break;
				}
				break;
			case GL_UNSIGNED_INT:
				switch (c->c.size) 
				{
					case 3: seethroughColor3uiv((GLuint *)p); break;
					case 4: seethroughColor4uiv((GLuint *)p); break;
				}
				break;
			case GL_FLOAT:
				switch (c->c.size) 
				{
					case 3: seethroughColor3fv((GLfloat *)p); break;
					case 4: seethroughColor4fv((GLfloat *)p); break;
				}
				break;
			case GL_DOUBLE:
				switch (c->c.size) 
				{
					case 3: seethroughColor3dv((GLdouble *)p); break;
					case 4: seethroughColor4dv((GLdouble *)p); break;
				}
				break;
		}
	}
	if (c->n.enabled) 
	{
		p = c->n.p + index*c->n.stride;
		switch (c->n.type) 
		{
			case GL_BYTE: seethrough_spu.super.Normal3bv((GLbyte *)p); break;
			case GL_SHORT: seethrough_spu.super.Normal3sv((GLshort *)p); break;
			case GL_INT: seethrough_spu.super.Normal3iv((GLint *)p); break;
			case GL_FLOAT: seethrough_spu.super.Normal3fv((GLfloat *)p); break;
			case GL_DOUBLE: seethrough_spu.super.Normal3dv((GLdouble *)p); break;
		}
	}
	if (c->v.enabled) 
	{
		p = c->v.p + (index*c->v.stride);

		switch (c->v.type) 
		{
			case GL_SHORT:
				switch (c->v.size) 
				{
					case 2: seethrough_spu.super.Vertex2sv((GLshort *)p); break;
					case 3: seethrough_spu.super.Vertex3sv((GLshort *)p); break;
					case 4: seethrough_spu.super.Vertex4sv((GLshort *)p); break;
				}
				break;
			case GL_INT:
				switch (c->v.size) 
				{
					case 2: seethrough_spu.super.Vertex2iv((GLint *)p); break;
					case 3: seethrough_spu.super.Vertex3iv((GLint *)p); break;
					case 4: seethrough_spu.super.Vertex4iv((GLint *)p); break;
				}
				break;
			case GL_FLOAT:
				switch (c->v.size) 
				{
					case 2: seethrough_spu.super.Vertex2fv((GLfloat *)p); break;
					case 3: seethrough_spu.super.Vertex3fv((GLfloat *)p); break;
					case 4: seethrough_spu.super.Vertex4fv((GLfloat *)p); break;
				}
				break;
			case GL_DOUBLE:
				switch (c->v.size) 
				{
					case 2: seethrough_spu.super.Vertex2dv((GLdouble *)p); break;
					case 3: seethrough_spu.super.Vertex3dv((GLdouble *)p); break;
					case 4: seethrough_spu.super.Vertex4dv((GLdouble *)p); break;
				}
				break;
		}
	}
}

void SEETHROUGHSPU_APIENTRY seethroughDrawArrays(GLenum mode, GLint first, GLsizei count) 
{
	int i;

	if (count < 0)
	{
		crError("seethroughDrawArrays passed negative count: %d", count);
	}

	if (mode > GL_POLYGON)
	{
		crError("seethroughDrawArrays called with invalid mode: %d", mode);
	}

	seethrough_spu.super.Begin (mode);
	for (i=0; i<count; i++) 
	{
		seethroughArrayElement(first++);
	}
	seethrough_spu.super.End();
}

void SEETHROUGHSPU_APIENTRY seethroughDrawElements(GLenum mode, GLsizei count, 
																			GLenum type, const GLvoid *indices) 
{
	int i;
	GLubyte *p = (GLubyte *)indices;

	if (count < 0)
	{
		crError("seethroughDrawElements passed negative count: %d", count);
	}

	if (mode > GL_POLYGON)
	{
		crError("seethroughDrawElements called with invalid mode: %d", mode);
	}

	if (type != GL_UNSIGNED_BYTE && type != GL_UNSIGNED_SHORT && type != GL_UNSIGNED_INT)
	{
		crError("seethroughDrawElements called with invalid type: %d", type);
	}
	
	seethrough_spu.super.Begin (mode);
	switch (type) 
	{
	case GL_UNSIGNED_BYTE:
		for (i=0; i<count; i++)
		{
			seethroughArrayElement((GLint) *p++);
		}
		break;
	case GL_UNSIGNED_SHORT:
		for (i=0; i<count; i++) 
		{
			seethroughArrayElement((GLint) * (GLushort *) p);
			p+=sizeof (GLushort);
		}
		break;
	case GL_UNSIGNED_INT:
		for (i=0; i<count; i++) 
		{
			seethroughArrayElement((GLint) * (GLuint *) p);
			p+=sizeof (GLuint);
		}
		break;
	default:
		crError( "this can't happen!" );
		break;
	}
	seethrough_spu.super.End();
}
