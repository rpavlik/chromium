#include "seethroughspu.h"

#include "cr_mothership.h"
#include "cr_string.h"

#include "state/cr_statetypes.h"

#include <stdio.h>

static void setOpacity( GLfloat o )
{
	if (o < 0.0) o = 0.0;
	if (0 > 1.0) o = 1.0;
    seethrough_spu.opacityb = (GLbyte) (o * GL_MAXBYTE);
    seethrough_spu.opacityd = (GLdouble) (o);
    seethrough_spu.opacityf = (GLfloat) (o);
    seethrough_spu.opacityi = (GLint) (o * GL_MAXINT);
    seethrough_spu.opacitys = (GLshort) (o * GL_MAXSHORT);
    seethrough_spu.opacityub = (GLubyte) (o * GL_MAXUBYTE);
    seethrough_spu.opacityui = (GLuint) (o * GL_MAXUINT);
    seethrough_spu.opacityus = (GLushort) (o * GL_MAXUSHORT);
}

static void __setDefaults( void )
{
	setOpacity( 0.5 );
	seethrough_spu.sfactor = GL_SRC_ALPHA;
	seethrough_spu.dfactor = GL_ONE_MINUS_SRC_ALPHA;
}

static void setBlendFuncFactor( const char *str, GLenum *factor )
{
#define BLEND_FUNC_COMPARE( s ) if (!crStrcmp( str, #s )) *factor = s
	BLEND_FUNC_COMPARE( GL_ZERO );
  BLEND_FUNC_COMPARE( GL_ONE );
  BLEND_FUNC_COMPARE( GL_DST_COLOR );
  BLEND_FUNC_COMPARE( GL_ONE_MINUS_DST_COLOR );
  BLEND_FUNC_COMPARE( GL_SRC_ALPHA );
  BLEND_FUNC_COMPARE( GL_ONE_MINUS_SRC_ALPHA );
  BLEND_FUNC_COMPARE( GL_DST_ALPHA );
  BLEND_FUNC_COMPARE( GL_ONE_MINUS_DST_ALPHA );
  BLEND_FUNC_COMPARE( GL_SRC_ALPHA_SATURATE );
  BLEND_FUNC_COMPARE( GL_SRC_COLOR );
  BLEND_FUNC_COMPARE( GL_ONE_MINUS_SRC_COLOR );
#undef BLEND_FUNC_COMPARE
}

void seethroughspuGatherConfiguration( void )
{
	CRConnection *conn;
	char response[8096];

	__setDefaults();

	// Connect to the mothership and identify ourselves.
	
	conn = crMothershipConnect( );
	if (!conn)
	{
		// The mothership isn't running.  Some SPU's can recover gracefully, some
		// should issue an error here.
		return;
	}
	crMothershipIdentifySPU( conn, seethrough_spu.id );

	if (crMothershipSPUParam( conn, response, "opacity" ))
	{
		GLfloat opacity;
		sscanf( response, "%f", &opacity );
		setOpacity( opacity );
	}

	if (crMothershipSPUParam( conn, response, "sfactor" ))
	{
		setBlendFuncFactor( response, &(seethrough_spu.sfactor) );
	}
	if (crMothershipSPUParam( conn, response, "dfactor" ))
	{
		setBlendFuncFactor( response, &(seethrough_spu.dfactor) );
	}

	crMothershipDisconnect( conn );
}
